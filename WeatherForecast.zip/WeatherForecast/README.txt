*****---------- Steps to run Application --------**********

Step1: Open Project solution "WeatherForecast.sln" in Visual studio 2017 and higher version.
Step2: Build solution.
Step3: Run Project.
Step4: Select City and Unit Dropdown.
Step5: Click on button "GetWeatherDetails"
Step6: Weather Details will show in Details section.


******---------- Steps to run Tests ------------********

Step1: Follow in Visual Studio, click on Test=>Windows=>Test Explorer
Step2: Select WeatherTest and right click and select RunSelectedTests.
Step3: Test result will show.

