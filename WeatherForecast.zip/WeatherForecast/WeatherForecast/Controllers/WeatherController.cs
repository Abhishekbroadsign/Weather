﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Script.Serialization;
using static WeatherForecast.Models.WeatherModel;

namespace WeatherForecast.Controllers
{
    public class WeatherController : ApiController
    {
        public string GetWeatherDetails(string city, string unit)
        {
            string appId = "ae1c4977a943a50eaa7da25e6258d8b2";
            string url = string.Format("http://api.openweathermap.org/data/2.5/weather?q={0}&units={2}&cnt=1&APPID={1}", city, appId, unit);

            using (WebClient client = new WebClient())
            {
                string json = client.DownloadString(url);
                Models.WeatherModel.WeatherInfo weatherInfo = (new JavaScriptSerializer()).Deserialize<WeatherInfo>(json);
                var result = WeatherDetailsMap.GetWeatherDetailsMap(weatherInfo);
                var jsonstring = new JavaScriptSerializer().Serialize(result);
                return jsonstring;
            }
        }
    }

    public static class WeatherDetailsMap {
        public static WeatherInfoViewModel GetWeatherDetailsMap(WeatherInfo weatherInfo)
        {
            WeatherInfoViewModel result = new WeatherInfoViewModel();
            result.City = weatherInfo.name;
            result.Temperature = Convert.ToString(weatherInfo.main.temp);
            result.MinTemperature = Convert.ToString(weatherInfo.main.temp_min);
            result.MaxTemperature = Convert.ToString(weatherInfo.main.temp_max);
            result.WindSpeed = weatherInfo.wind.speed;
            return result;
            
        }
    }
}

