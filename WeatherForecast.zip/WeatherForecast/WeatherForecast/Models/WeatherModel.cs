﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WeatherForecast.Models
{
    public class WeatherModel
    {
        public class WeatherInfoViewModel
        {
            public string City { get; set; }
            public string Temperature { get; set; }
            public string MinTemperature { get; set; }
            public string MaxTemperature { get; set; }
            public double WindSpeed { get; set; }
        }
        public class WeatherInfo
        {
            public Main main { get; set; }
            public Wind wind { get; set; }
            public string name { get; set; }
        }
        public class Main
        {
            public double temp { get; set; }
            public double temp_min { get; set; }
            public double temp_max { get; set; }
        }
        public class Wind
        {
            public double speed { get; set; }
        }
    }
}