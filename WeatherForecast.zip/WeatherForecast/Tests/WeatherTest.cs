﻿using System;
using System.Collections.Generic;
using System.Text;
using Xunit;
using WeatherForecast.Controllers;
using System.Net;
using static WeatherForecast.Models.WeatherModel;

namespace Tests
{
    public class WeatherTest
    {
       
        [Fact]
        public void When_inputs_are_correct_then_result_are_correct()
        {
            WeatherInfo weatherInfo = new WeatherInfo
            {
               name = "London",
               main = new Main{
                   temp = 10.0,
                   temp_min= 1.0,
                   temp_max = 12.0
               },
               wind = new Wind {
                   speed = 3.6
               }
            };
            var result = WeatherDetailsMap.GetWeatherDetailsMap(weatherInfo);
            Assert.Equal("London", result.City);
            Assert.Equal(10.0, Convert.ToDouble(result.Temperature));
            Assert.Equal(1.0, Convert.ToDouble(result.MinTemperature));
            Assert.Equal(12.0, Convert.ToDouble(result.MaxTemperature));
            Assert.Equal(3.6, Convert.ToDouble(result.WindSpeed));
        }
    }

    
}
